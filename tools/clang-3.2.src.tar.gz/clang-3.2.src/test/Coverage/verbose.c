// RUN: %clang_cc1 -fsyntax-only -v %s

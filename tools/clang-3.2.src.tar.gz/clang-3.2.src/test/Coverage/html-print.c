// RUN: %clang_cc1 -emit-html -o %t %s

#include "c-language-features.inc"

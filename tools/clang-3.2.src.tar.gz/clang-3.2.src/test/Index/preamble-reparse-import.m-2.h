#ifdef PARSED
#error parsed twice
#endif

#define PARSED 1

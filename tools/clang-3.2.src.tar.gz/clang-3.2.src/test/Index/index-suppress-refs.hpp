
class B1 {};
class B2 {};

#pragma once
int i;


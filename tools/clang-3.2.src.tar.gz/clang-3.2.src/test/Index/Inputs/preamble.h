inline int bar(int i) {
  int *ptr = 0;
  float *ptr1;
  ptr = ptr1;
  return 0;
}

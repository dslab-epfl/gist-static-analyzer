int f0(int *pointer1, float *pointer2) {
  return pointer2 - pointer1;
}

void g() {
  

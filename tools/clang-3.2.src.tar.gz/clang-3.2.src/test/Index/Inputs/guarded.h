#ifndef GUARDED_HEADER_H
#define GUARDED_HEADER_H

int y;

#endif // GUARDED_HEADER_H

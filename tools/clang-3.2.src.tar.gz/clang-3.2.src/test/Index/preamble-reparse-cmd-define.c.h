extern int x;

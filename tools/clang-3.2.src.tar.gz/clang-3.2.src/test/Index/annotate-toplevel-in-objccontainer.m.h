@interface FooPCH
void funcPCH1(int);
void funcPCH2(int);

enum E { Cake };

-(void)meth1;
-(void)meth2;
@end

// RUN: c-index-test -test-load-source all %s
// All we care about in this test is that it doesn't crash.
typedef r7833619_a (*r7833619_b)(r7833619_c *r7833619_d, r7833619_c *r7833619_e);


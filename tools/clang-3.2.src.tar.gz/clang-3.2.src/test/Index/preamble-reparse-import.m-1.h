#ifdef PARSED2
#error parsed twice
#endif

#define PARSED2 1

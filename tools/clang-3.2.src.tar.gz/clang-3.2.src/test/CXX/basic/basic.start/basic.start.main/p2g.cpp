// RUN: %clang_cc1 -fsyntax-only -verify %s 
// expected-no-diagnostics

int main(int argc, const char* const* argv) {
}
